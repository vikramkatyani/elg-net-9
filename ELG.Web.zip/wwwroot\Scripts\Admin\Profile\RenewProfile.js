﻿$(function () {
    UTILS.activateNavigationLink('profileLink');
    UTILS.activateMenuNavigationLink('menu-renew-profile');
});

