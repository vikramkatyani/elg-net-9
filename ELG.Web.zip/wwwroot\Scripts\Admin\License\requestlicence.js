﻿$(function () {
    UTILS.activateNavigationLink('licenceLink');
    UTILS.activateMenuNavigationLink('menu-license-request');
    $('[data-toggle="tooltip"]').tooltip();
});