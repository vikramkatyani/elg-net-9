﻿$(function () {
    UTILS.activateNavigationLink('profileLink');
    UTILS.activateMenuNavigationLink('menu-manage-profile');
    $('[data-toggle="tooltip"]').tooltip();
});