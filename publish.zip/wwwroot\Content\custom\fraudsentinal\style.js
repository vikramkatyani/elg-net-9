
document.addEventListener("DOMContentLoaded", function () {
  const heading = document.querySelector("#introTxt"); 

  // Change the text content
  if (heading) {
    heading.innerHTML = "Fraud Compliance <br />Training Solutions";
  }
});